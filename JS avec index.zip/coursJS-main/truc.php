<?php
if(isset($_POST['envoi'])){ // si formulaire soumis
echo $_POST['pseudo'];
}
?>