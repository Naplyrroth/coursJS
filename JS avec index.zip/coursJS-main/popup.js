window.confirm("BONJOUR MONSIEUR");
alert("Nous Vous Présentont Notre Site Internet");
alert("Allez-vous nous donner une bonne note ?");
nVarNom = prompt("Allez-vous me donner une bonne note ?","oui")